---
name: videos-de-ubicacion
description: Genera videos verticales de mapa 3D (1080×1920, 7 s) para anuncios inmobiliarios de Invicta. Usala cuando pidan "mapas", "videos de ubicación", "videos de zona", "generar los mapas del guion", mostrar barrios, calles o una ciudad (CABA, Recoleta, Palermo…), o los 2 videos de una propiedad a partir de un link de Google Maps. Entrega los MP4 en el chat o los sube a la carpeta «Material Productos» del cliente en Google Drive.
---

# Videos de ubicación (Invicta)

Herramienta propia de Invicta. Dos productos:

| Producto | Entrada | Salida |
|---|---|---|
| **Propiedad** | Link de Google Maps (corto, largo o coordenadas) | 2 videos: «Ubicación 50 km» y «Entorno» (3D, calle iluminada, referencias cercanas) |
| **Zonas** | Un pedido con uno o más videos, cada uno con sus zonas (barrios, calles, ciudad) | 1 video por renglón: la cámara recorre las zonas en orden y cada una se ilumina al llegar |

Reglas de estilo (ya las cumple el motor; no las cambies sin que lo pidan): 7 s, 1080×1920, H.264, como máximo 2 carteles a la vez además del principal, contornos aproximados y redondeados, sobrio.

## Paso 1 — Instalar o actualizar el motor (siempre, es rápido)

```bash
bash ~/.claude/skills/videos-de-ubicacion/scripts/instalar.sh
```

Si responde `MODO: solo Drive`, en esta Mac no se puede generar localmente (falta acceso al motor o el token): usá únicamente `drive.sh` (los genera GitHub y quedan en la carpeta de Drive). Si responde `MODO: completo`, podés usar las dos vías.

## Paso 2a — Videos de ZONAS a partir de un guion

1. Leé el guion completo (puede venir como imagen, Google Doc o texto). Si hay que abrir un Doc o una carpeta de Drive, usá el conector de Google Drive.
2. **Un video por cada gancho o bloque del cuerpo que nombre lugares.** Los que no nombran lugares no llevan mapa: decilo.
   - Si un bloque habla de «la Ciudad» en general, no hagas un video aparte: decí que puede reusarse el de la ciudad entera (si hay uno) o agregá uno con `["CABA"]` si no existe.
3. Escribí el pedido en un archivo JSON (ejemplo completo en `ejemplo-pedido.json`):
   - `contexto`: la ciudad donde se buscan las zonas (por defecto `Ciudad Autónoma de Buenos Aires`).
   - `subtitulo`: línea chica arriba (ej. `Ciudad de Buenos Aires`); en el video de la ciudad entera usá el país.
   - `videos`: `[{ "nombre": "Hook 1 - Recoleta Palermo Belgrano", "zonas": [...] }]`. El `nombre` es el nombre del archivo: usá la misma numeración del guion (Hook 4 es «Hook 4», aunque sea el tercer video).
   - Zonas: texto (`"Recoleta"`, `"CABA"`, `"Calle Florida"`, `"Av. Cabildo"`) u objeto (`{ "nombre": "Barrio Norte", "limites": ["Av. Córdoba", "Av. 9 de Julio", "Av. del Libertador", "Av. Coronel Díaz"] }`).
   - Las calles empiezan con `Calle`, `Av.`, `Bv.`, `Pasaje` o `Diagonal`, o llevan `"tipo": "calle"`.
4. **Orden:** la cámara recorre las zonas en el orden del array, y el editor sincroniza cada zona con la voz en off. Por defecto respetá el orden en que se nombran en el guion. Si ese orden obliga a ir y volver por el mapa, **preguntale al usuario** antes de generar si prefiere el orden del guion o el geográfico. Si no podés preguntar, respetá el guion y mencionalo en la entrega.
   - Excepción: una frase que describe un recorrido («de Florida a Cabildo, pasando por Recoleta, Palermo y Belgrano») se arma como el recorrido (Florida → Recoleta → Palermo → Belgrano → Cabildo).
5. **Barrios no oficiales** (Barrio Norte, Microcentro, Palermo Soho, etc.): no tienen contorno en OpenStreetMap. Buscá una fuente (ej. Wikipedia) con sus calles límite y pasalas en `limites`, en orden alrededor de la zona. Si no hay fuente, el motor dibuja un círculo de 800 m y lo avisa. Nunca inventes límites: decí de dónde salen.
6. Si el usuario quiere elegir cosas (orden, zonas dudosas), mostrále el plan antes de generar.

## Paso 2b — Videos de una PROPIEDAD

Solo hace falta el link de Google Maps. Opcional: título y puntos a destacar (uno por renglón, «Nombre» o «Nombre: link»).

## Paso 3 — Generar

**En esta Mac y entregar por el chat** (lo más rápido: 1–1,5 min por video; usa la placa de video):

```bash
bash ~/.claude/skills/videos-de-ubicacion/scripts/zonas-local.sh pedido.json carpeta-de-salida
bash ~/.claude/skills/videos-de-ubicacion/scripts/propiedad-local.sh "LINK" carpeta-de-salida ["PUNTOS"] ["TITULO"]
```

Corré estos comandos en segundo plano (tardan varios minutos) y esperá el aviso de fin. Cada video terminado imprime `LISTO: ruta`.

**En la carpeta de Drive del cliente** (los genera GitHub en tramos paralelos: unos 10–15 min por pedido de propiedad y 10–20 min por pedido de zonas; no hace falta esta Mac encendida):

```bash
S=~/.claude/skills/videos-de-ubicacion/scripts
bash $S/drive.sh clientes "urban"                    # buscar el cliente → id
bash $S/drive.sh carpeta "https://drive.google.com/drive/folders/…"   # o validar una carpeta propia
bash $S/drive.sh zonas DESTINO pedido.json           # DESTINO = id de cliente o enlace de carpeta → pedido
bash $S/drive.sh propiedad DESTINO "LINK" ["TITULO"] ["PUNTOS"]
bash $S/drive.sh esperar PEDIDO                      # opcional: muestra el avance y, al final, los links (se guardan solos aunque no esperes)
```

**Carpeta propia:** si el usuario da un enlace de carpeta de Drive en lugar de un cliente, validala primero con `drive.sh carpeta`. Si falla, decile textualmente: «Recordá que los permisos deben estar abiertos al público para que pueda acceder a esta carpeta de Google Drive: Compartir → Acceso general → Cualquier persona con el enlace → Editor.»

Si el usuario no dijo dónde, generá en esta Mac, entregá por el chat y ofrecé subirlos a Drive.

## Paso 4 — Revisar antes de entregar (obligatorio)

Sacá una hoja de 12 cuadros de cada video y mirala. No entregues sin mirar:

```bash
bash ~/.claude/skills/videos-de-ubicacion/scripts/revisar.sh "carpeta/Hook 1 - ….mp4"   # → imprime REVISION: ruta.png
```

Fijate que cada zona del pedido aparezca iluminada y con su nombre, en el orden pedido, que los nombres no se pisen ni se corten. Los contornos en las miniaturas son finos: si dudás de uno, sacá ese cuadro en grande con ffmpeg antes de concluir que falta. Si algo está mal, corregí el pedido y volvé a generar ese video.

## Paso 5 — Entregar

Mandá los MP4 al usuario (en el chat con la herramienta de enviar archivos, o los links de Drive). Explicá en lenguaje simple qué muestra cada uno, qué fue aproximado (con la fuente) y qué no se pudo hacer.

## Avisos que siempre hay que dar

- **Licencia:** el 3D usa un token de Cesium del plan gratis, que no permite uso comercial. Antes de pautar hay que pasar al plan comercial o usar una clave de Google Maps con facturación.
- Los barrios no oficiales son aproximados.

## Problemas conocidos

- «No encontré la calle/barrio X»: probá con el nombre completo (`Avenida del Libertador`), agregá `Calle`/`Av.`, o cambiá `contexto`.
- Overpass (OpenStreetMap) se cae seguido: el motor usa Nominatim como respaldo, pero puede tardar más.
- App web para el equipo (mismo motor, sin Claude): https://gaelmusa.github.io/video-ubicacion-app/
