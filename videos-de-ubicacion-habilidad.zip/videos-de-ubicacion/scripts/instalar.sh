#!/bin/bash
# Instala o actualiza el motor (repositorio privado gaelmusa/video-ubicacion) dentro de la habilidad.
# Si esta Mac no tiene acceso al motor o al token de Cesium, la habilidad funciona en «modo solo Drive».
export PATH=/opt/homebrew/bin:/usr/local/bin:$PATH
DIR="$(cd "$(dirname "$0")/.." && pwd)"
M="$DIR/motor"
command -v node >/dev/null || { echo "Falta node (https://nodejs.org o brew install node). Sin node no funciona ningún modo."; exit 1; }
solo_drive() { echo "MODO: solo Drive — $1. Usá solo drive.sh (los videos los genera GitHub y quedan en Drive)."; exit 0; }
command -v gh >/dev/null || solo_drive "falta gh"
command -v ffmpeg >/dev/null || solo_drive "falta ffmpeg"
if [ ! -d "$M/.git" ]; then
  gh repo clone gaelmusa/video-ubicacion "$M" -- -q 2>/dev/null || solo_drive "esta cuenta de GitHub no tiene acceso al motor"
else
  git -C "$M" pull -q --ff-only 2>/dev/null || echo "AVISO: no se pudo actualizar el motor; se usa la versión local."
fi
cd "$M"
if [ ! -d node_modules ] || [ package-lock.json -nt node_modules/.package-lock.json ]; then npm ci --silent || solo_drive "no se pudieron instalar las dependencias"; fi
[ -f .env ] || solo_drive "falta $M/.env con CESIUM_ION_TOKEN=…"
echo "MODO: completo — motor listo en $M (podés generar en esta Mac o mandar a Drive)."
