#!/bin/bash
# Uso: propiedad-local.sh "LINK de Google Maps" carpeta-de-salida ["PUNTOS"] ["TITULO"]
set -e
export PATH=/opt/homebrew/bin:/usr/local/bin:$PATH
DIR="$(cd "$(dirname "$0")/.." && pwd)"
[ -n "$1" ] || { echo 'Uso: propiedad-local.sh "LINK" carpeta-de-salida ["PUNTOS"] ["TITULO"]'; exit 1; }
OUT="${2:-videos-propiedad}"; mkdir -p "$OUT"; OUT="$(cd "$OUT" && pwd)"
cd "$OUT" && LINK="$1" PUNTOS="${3:-}" TITULO="${4:-}" node "$DIR/motor/render/job.js" 2>&1 | grep -E "ERROR|aviso" || true
[ -f "$OUT/salida/info.json" ] && node -e 'const i=require(process.argv[1]);if(!i.ok){console.log("ERROR: "+i.error);process.exit(1)}' "$OUT/salida/info.json"
for f in "$OUT"/salida/*.mp4; do echo "LISTO: $f"; done
