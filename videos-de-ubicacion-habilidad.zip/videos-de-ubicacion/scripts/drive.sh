#!/bin/bash
export PATH=/opt/homebrew/bin:/usr/local/bin:$PATH
exec node "$(cd "$(dirname "$0")" && pwd)/drive.js" "$@"
