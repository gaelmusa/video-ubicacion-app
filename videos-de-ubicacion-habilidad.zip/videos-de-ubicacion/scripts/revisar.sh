#!/bin/bash
# Uso: revisar.sh video.mp4 [salida.png]  → hoja con 12 cuadros repartidos en todo el video (2 filas de 6)
export PATH=/opt/homebrew/bin:/usr/local/bin:$PATH
V="$1"; OUT="${2:-${1%.mp4}-revision.png}"
[ -f "$V" ] || { echo "Uso: revisar.sh video.mp4 [salida.png]"; exit 1; }
N=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of default=nk=1:nw=1 "$V" | tr -dc '0-9')
STEP=$(( (N - 1) / 11 ))
SEL=""; for i in $(seq 0 11); do SEL="${SEL}eq(n\\,$(( i * STEP )))+"; done; SEL=${SEL%+}
ffmpeg -v error -y -i "$V" -vf "select=$SEL,scale=240:-1,tile=6x2:padding=4:color=white" -frames:v 1 "$OUT" && echo "REVISION: $OUT (cuadros cada $STEP de $N)"
