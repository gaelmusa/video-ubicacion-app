// Pedidos a la app de Drive (Apps Script público). Uso en drive.sh.
'use strict';
const fs = require('fs');
const API = 'https://script.google.com/macros/s/AKfycbwjMvfXmM1VxN3NjsVgFyNGRaCcCUTJCNQ99hdCJ1SxsIXNItP3Z-144XGtX56y_cz6FA/exec';
async function call(fn, ...args) {
  const r = await fetch(`${API}?fn=${encodeURIComponent(fn)}&args=${encodeURIComponent(JSON.stringify(args))}`, { redirect: 'follow' });
  if (!r.ok) throw new Error('La app respondió ' + r.status);
  const j = await r.json();
  if (!j.ok) throw new Error(j.error);
  return j.data;
}
// Destino: id de cliente (de «clientes») o enlace de una carpeta de Drive abierta al público
const destino = x => /^https?:\/\//.test(x || '') ? { carpeta: x } : x;
const norm = s => String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
(async () => {
  const [cmd, a, b, c, d] = process.argv.slice(2);
  if (cmd === 'carpeta') {
    const c = await call('verificarCarpeta', a);
    console.log(`OK: se puede guardar en «${c.nombre}» ${c.url}`);
  } else if (cmd === 'clientes') {
    const l = await call('listarClientes');
    for (const x of l.filter(x => !a || norm(x.nombre).includes(norm(a)))) console.log(`${x.id}\t${x.nombre}`);
  } else if (cmd === 'zonas') {
    const r = await call('generarZonas', destino(a), JSON.parse(fs.readFileSync(b, 'utf8')));
    console.log(`PEDIDO: ${r.pedido}\nCarpeta: ${r.carpeta}\nVideos: ${r.videos}`);
  } else if (cmd === 'propiedad') {
    const r = await call('generar', destino(a), b, c || '', d || '');
    console.log(`PEDIDO: ${r.pedido}\nCarpeta: ${r.carpeta}`);
  } else if (cmd === 'estado' || cmd === 'esperar') {
    let last = '';
    for (;;) {
      const s = await call('estado', a);
      const linea = s.fase === 'guardando' ? `guardando en Drive ${s.hechos}/${s.total}` : s.fase + (s.segundos ? ` (${Math.round(s.segundos / 60)} min)` : '');
      if (linea !== last) console.log(linea);
      last = linea;
      if (s.fase === 'listo') { for (const f of s.archivos) console.log(`ARCHIVO: ${f.nombre}\t${f.url}`); console.log(`CARPETA: ${s.carpeta}`); return; }
      if (s.fase === 'error') throw new Error(s.mensaje);
      if (cmd === 'estado') return;
      await new Promise(r => setTimeout(r, 30000));
    }
  } else {
    console.log('Uso: drive.sh clientes [filtro] | carpeta URL | zonas DESTINO pedido.json | propiedad DESTINO LINK [TITULO] [PUNTOS] | estado PEDIDO | esperar PEDIDO   (DESTINO = id de cliente o enlace de carpeta de Drive)');
    process.exit(1);
  }
})().catch(e => { console.error('ERROR: ' + e.message); process.exit(1); });
