#!/bin/bash
# Uso: zonas-local.sh pedido.json carpeta-de-salida   → un MP4 por video del pedido
set -e
export PATH=/opt/homebrew/bin:/usr/local/bin:$PATH
DIR="$(cd "$(dirname "$0")/.." && pwd)"
[ -f "$1" ] || { echo "Uso: zonas-local.sh pedido.json carpeta-de-salida"; exit 1; }
PEDIDO="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
OUT="${2:-videos-zonas}"; mkdir -p "$OUT"; OUT="$(cd "$OUT" && pwd)"
cd "$DIR/motor" && node render/zonas-cli.js "$PEDIDO" "$OUT"
